function varargout = permute(varargin)
% file_array objects can not be permuted
%__________________________________________________________________________
% Copyright (C) 2005-2017 Wellcome Trust Centre for Neuroimaging

%
% $Id: permute.m 7147 2017-08-03 14:07:01Z spm $


error('file_array objects can not be permuted.');
